<?php
// Set up database connection variables
$host = "127.0.0.1";
$username = "s2563191";
$password = "s2563191";
$database = "d2563191";

// Establish database connection
$conn = mysqli_connect($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$rating = $_POST['rating'];
$itemID = $_POST['itemID'];
$emailAddress = $_POST['emailAddress'];

// Check if the user has already rated the item
$checkQuery = "SELECT * FROM RATINGS WHERE ITEM_ID = '$itemID' AND EMAIL_ADDRESS = '$emailAddress'";
$checkResult = $conn->query($checkQuery);

if ($checkResult->num_rows > 0) {
    // User has already rated the item
    echo "Already rated";
} else {
    // Insert the rating into the RATINGS table
    $insertQuery = "INSERT INTO RATINGS (ITEM_ID, RATING, EMAIL_ADDRESS) VALUES ('$itemID', '$rating', '$emailAddress')";

    if ($conn->query($insertQuery) === TRUE) {
        // Rating inserted successfully
        echo "Rating submitted";
    } else {
        // Failed to insert rating
        echo "Failed to submit rating";
    }
}

$conn->close();
?>