<?php
// Enable error reporting
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Set up database connection variables
$host = "127.0.0.1";
$username = "s2563191";
$password = "s2563191";
$database = "d2563191";

// Establish database connection
$conn = mysqli_connect($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$dbdata = array();

$result = $conn->query("SELECT ITEM_NAME, PRICE, ITEM_ID FROM ITEMS ORDER BY DATE_POSTED");

while ($row = $result->fetch_assoc()) {
    $dbdata[] = $row;
}

echo json_encode($dbdata);
?>