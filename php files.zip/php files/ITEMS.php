<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Set up database connection variables
$host = "127.0.0.1";
$username = "s2563191";
$password = "s2563191";
$database = "d2563191";

// Connect to the database
$conn = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve user input from the form
$ItemName = $_POST["ItemName"];
$description = $_POST["description"];
$price = $_POST["price"];
$datePosted = $_POST["datePosted"];
$sellerName = $_POST["sellerName"];
$emailAdd = $_POST["emailAdd"];


// Prepare SQL query to insert user credentials into the database
$sql = "INSERT INTO ITEMS (ITEM_NAME, DESCRIPTION, PRICE, DATE_POSTED, SELLER_NAME, EMAIL_ADDRESS) VALUES ('$ItemName', '$description', '$price', '$datePosted', '$sellerName', '$emailAdd')";

// Execute the query
if (mysqli_query($conn, $sql)) {
    $response = array("message" => "Item successfully added");
    echo json_encode($response);
} else {
	$response = array("message" => "Failed to add item");
	echo json_encode($response);
}

// Close database connection
mysqli_close($conn);
?>