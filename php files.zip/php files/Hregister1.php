<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Set up database connection variables
$host = "127.0.0.1";
$username = "s2563191";
$password = "s2563191";
$database = "d2563191";

// Connect to the database
$conn = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve user input from the form
$name = $_POST["name"];
$surname = $_POST["surname"];
$dateOfBirth = $_POST["dob"];
$email = $_POST["email"];
$password = $_POST["password"];

// Check if the user already exists in the database
$checkQuery = "SELECT * FROM PEOPLE WHERE EMAIL_ADDRESS = '$email'";
$result = mysqli_query($conn, $checkQuery);
if (mysqli_num_rows($result) > 0) {
    // User already exists
    $response = array("message" => "User already exists");
    echo json_encode($response);
} else {
    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Prepare SQL query to insert user credentials into the database
    $sql = "INSERT INTO PEOPLE (PASSWORD, EMAIL_ADDRESS, NAME, SURNAME, DATE_OF_BIRTH) VALUES ('$hashedPassword', '$email', '$name', '$surname', '$dateOfBirth')";

    // Execute the query
    if (mysqli_query($conn, $sql)) {
        $response = array("message" => "User registration successful");
        echo json_encode($response);
    } else {
        $response = array("message" => "User registration failed");
        echo json_encode($response);
    }
}

// Close database connection
mysqli_close($conn);
?>