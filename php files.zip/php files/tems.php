<?php
// Database configuration
$host = "127.0.0.1";
$username = "s2563191";
$password = "s2563191";
$database = "d2563191";

// Create a connection to the MySQL database
$connection = new mysqli($host, $username, $password, $database);

// Check for any connection errors
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Retrieve the item ID from the request
$itemID = $_POST["itemID"];

// Prepare the SQL statement
$query = "SELECT ITEM_NAME, DESCRIPTION, PRICE, SELLER_NAME, EMAIL_ADDRESS FROM ITEMS WHERE ITEM_ID = ?";
$statement = $connection->prepare($query);
$statement->bind_param("s", $itemID);

// Execute the query
$statement->execute();

// Bind the result to variables
$statement->bind_result($itemName, $itemDesc, $itemPrice, $seller, $email);

// Create an associative array to hold the item details
$itemDetails = array();

// Fetch the result
while ($statement->fetch()) {
    $itemDetails["itemName"] = $itemName;
    $itemDetails["itemPrice"] = $itemPrice;
    $itemDetails["itemDesc"] = $itemDesc;
    $itemDetails["seller"] = $seller;
    $itemDetails["Email"] = $email;
}

// Convert the item details array to JSON format
$itemDetailsJson = json_encode($itemDetails);

// Return the item details as JSON response
echo $itemDetailsJson;

// Close the statement and database connection
$statement->close();
$connection->close();
?>