<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set up database connection variables
$host = "127.0.0.1";
$username = "s2563191";
$password = "s2563191";
$database = "d2563191";

// Connect to the database
$conn = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve user input from login form
$email = $_POST["email"];
$password = $_POST["password"];

// Prepare SQL query with parameterized statement to check if user credentials exist in the database
$sql = "SELECT * FROM PEOPLE WHERE EMAIL_ADDRESS = ?";

// Create a prepared statement
$stmt = mysqli_prepare($conn, $sql);

// Bind the parameter (email) to the statement
mysqli_stmt_bind_param($stmt, "s", $email);

// Execute the statement
mysqli_stmt_execute($stmt);

// Get the result from the statement
$result = mysqli_stmt_get_result($stmt);

// Check if query returned any rows
if (mysqli_num_rows($result) == 1) {
    // Fetch the row from the result
    $row = mysqli_fetch_assoc($result);
    $storedPassword = $row["PASSWORD"];
    
    // Verify the entered password against the stored password hash
    if (password_verify($password, $storedPassword)) {
        // User credentials are valid
        // Return user ID as JSON object
        $response = array("EMAIL" => $email);
        echo json_encode($response);
    } else {
        // Invalid password
        $response = array("error" => "Invalid password");
        echo json_encode($response);
    }
} else {
    // User not found
    $response = array("error" => "User not found");
    echo json_encode($response);
}

// Close statement
mysqli_stmt_close($stmt);

// Close database connection
mysqli_close($conn);
?>